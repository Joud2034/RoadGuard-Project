RoadGuard - YOLO11 Road Damage Detection
========================================
RoadGuard_YOLO.ipynb            Colab notebook (training, evaluation, comparison table)

results/
  classical_vs_yolo.csv         Final comparison on the SAME 900 Test images (IoU >= 0.5)
  yolo_summary.json             Settings + Test metrics (mAP@0.5, mAP@0.5:0.95, P, R, F1)
  yolo_test_per_class_ap50.csv  Test AP@0.5 per damage class
  yolo_val_threshold_sweep.csv  Confidence threshold selection on Validation (best = 0.25)

figures/
  yolo_test_examples.png        Test examples: ground truth (green) vs YOLO (red)

training_run/
  results.png / results.csv     Training & validation curves for 50 epochs
  args.yaml                     Full training settings

test_evaluation/
  BoxPR_curve.png               Precision-Recall curve on Test (mAP@0.5 = 0.475)
  BoxF1_curve.png               F1-Confidence curve on Test
  confusion_matrix.png          Confusion matrix on Test

Trained model (best.pt, 19 MB) is on Drive:
RoadGuard_Project/YOLO_Runs/yolo11s_rdd_6000/weights/best.pt
